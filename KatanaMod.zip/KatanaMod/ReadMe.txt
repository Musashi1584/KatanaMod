﻿[h1]This is vblanco20-1[ESP] Katana Pack reloaded.[/h1]
I have the honour to continue his mod with his permission.

[h1]Works with and without LW2[/h1]

V 1.8 LW2 Compatibility
V 1.7.1 Doom and Vortex Ninjato only have a 50 % chance to apply panic
V 1.7 Exposes archetype, icon and abilities to config. Added dedicated Doom Ninjato and Vortex Ninjato model
V 1.6 Introduced Global Suspicion Level and Suspicion UI 
V 1.5 Added Tier 3 Ninjato and Vortex Variants of Ninjato, Wakizashi and Katana
V 1.4.1 Hiding previous tiers when new sword tier is bought
V 1.4 Added visual effect for silent takedown
V 1.3 New silent kill mechanics and pod activation on takedown
V 1.2 Added Grimys Utility Slot Sidearms Mod support and Tier 1 Ninjato
V 1.1 Added lightning slash to wakizashi
V 1.0 Initial release

[u]Higher tiers are unlocked when you buy the coresponding sword tier.[/u]
There are no additional costs.

[u]There is a config value if you only want cosmetic variants which have no stat difference to the vanilla swords[/u]
just set 
bNinjatoIsCosmetic=true
bKatanaIsCosmetic=true
bWakizashiIsCosmetic=true
(Default is false)

[h1]The stats[/h1]

[url=http://steamcommunity.com/workshop/filedetails/discussion/698579656/361798516958457261/]Click here for the stats[/url]

[u]This mod comes with a default integration to Grimys Loot Mod and Grimys Utility Slot Sidearms[/u]

[u]This mod should work on existing save games.[/u]
There is an issue that if you have unlocked the higher tiers with the old katana mod there are still unlocked.

[u]Credits[/u]
All credits of the conventional katana model and the original implementation to vblanco20-1[ESP].
The energy and plasma katana models, all wakizashi and all ninjato models are from escrimator.
Dōmo arigatō vblanco20-1[ESP] and escrimator. You are the best guys!

Thanks and Credits to Long War Studios for the fleche ability code and LW2.

Thanks to resonansER for the russian translation!
Thanks to Erazil for the french translation!
Thanks to [PTT]Kei for the traditional chinese translation!
Thanks to luga.sg for the simple chinese translation!
Thanks to a8a for helping me getting rid of typos in the english version!

ModID: 698579656

Possible issues:
It was reported that this mod may produce a crash after the tutorial misson.
I can't reproduce it, i have this crash with or without mods active.

[h1]FAQ[/h1]

Q: I don't see the mobility bonus in the UI/Ninjato don't give mobility bonus?

A: Remove the relevant lines in XComUI.ini and you will see the mobility bonus. 
The downside is it will show the swords aim bonus on your soldier then.
Nothing i can do about that.